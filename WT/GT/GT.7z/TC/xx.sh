rm -rf /data/adb/TC
cp ./build/TC /data/adb/TC
chmod -R 777 /data/adb/TC
/data/adb/TC
rm -rf /data/adb/TC