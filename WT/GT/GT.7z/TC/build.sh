rm -rf build
mkdir build && cd build 
cmake .. && make
chmod -R 777 TC
